/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import model.Business.Business;
import model.Business.ConfigureABusiness;

/**
 *
 * @author kal bugrara
 */
public class PricingModel {
    //public static Business business;
  /**
   * @param args the command line arguments
   */
//  public static void main(String[] args) {
//    // TODO code application logic here
//    Business business = ConfigureABusiness.createABusinessAndLoadALotOfData("Xerox", 5, 500);
//    System.out.print(business.toString());
//    //business.toString();
//  }
    
//    public static Business initialize(){
//        Business business = business = ConfigureABusiness.createABusinessAndLoadALotOfData("Xerox", 5, 500);
//        
//        return business;
//    }

// Jiaen Branch Test 2.0
// qianyi testing
// mengge testing
}
